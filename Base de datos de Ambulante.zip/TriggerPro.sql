-- PRIMER TRIGGER
DROP TRIGGER IF EXISTS ActualizarFestival;
DELIMITER #
CREATE TRIGGER ActualizarFestival
AFTER UPDATE ON festival
FOR EACH ROW
BEGIN
IF NEW.Fecha <> OLD.Fecha THEN 
INSERT INTO festival (idFestival, NombreFestival, Fecha)VALUES (NEW.idFestival, NombreFestival, Fecha);
END IF;
END#
DELIMITER ;

DELETE FROM festival WHERE idFestival LIKE '%31%';

update festival
set fecha = 2021-06-22
where idFestival = '31';

update festival
set NombreFestival = 'Prueba2'
where idFestival = '32';

rollback;
INSERT INTO festival (idFestival, NombreFestival, fecha)VALUES ('31', 'Prueba', '2021-06-21');
SELECT * FROM festival;
SET SQL_SAFE_UPDATES = 0;

-- SEGUNDO TRIGGER
DELIMITER #
CREATE TRIGGER MAXFecha
BEFORE INSERT on documentales
FOR EACH ROW
BEGIN
IF New.año > 2021 THEN
SET New.año = 2021;
END IF;
END#
DELIMITER ;

INSERT INTO documentales (idDocumentales, Nombre, Sinopsis, Director, Año, Duración, Colección, ProyectoEspecial, Semblanza) values (55,'Gueros','In the opening scene, a young mother takes her crying infant outside in a stroller, only to be hit by a water balloon dropped by Tomas from the rooftop of the apartment building. When Tomas mother finds out, she decides to send him to stay with his older brother Sombra, a student in Mexico City, and Sombras roommate Santos. After a bus ride, he arrives at his brothers home late at night. The apartment is dark without electricity. The following morning there is no breakfast.','Alonso Ruizpalacios','2023','106','Contemporanea','Canes','Lorem');

SELECT * FROM documentales WHERE idDocumentales LIKE '%5'