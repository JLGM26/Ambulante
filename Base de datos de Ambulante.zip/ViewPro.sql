-- PRIMER VIEW
DROP VIEW Vista_Busqueda;
CREATE VIEW VistaBusqueda AS
	SELECT d.idDocumentales AS ID, d.nombre AS Nombre, d.sinopsis AS Sinopsis, e.NombreEtiqueta AS Etiquetas
    FROM documentales d, etiquetas e
    WHERE d.idDocumentales = e.idEtiquetas;

SHOW CREATE VIEW Vista_Busqueda;

SELECT * FROM VistaBusqueda WHERE Etiquetas LIKE 'A%' ORDER BY etiquetas ASC;

-- SEGUNDO VIEW
DROP VIEW VistaIdioma;
CREATE VIEW VistaIdioma AS
	SELECT i.IdiomaUsado AS Idioma, d.Nombre, d.Año
	FROM documentales d, idioma i
    WHERE d.idDocumentales = i.idIdioma;

SELECT * FROM VistaIdioma ORDER BY Nombre DESC;

-- TERCER VIEW
DROP VIEW Vistafestival;
CREATE VIEW VistaFestival AS
	SELECT f.Fecha, f.NombreFestival AS NombreFestival, d.Nombre AS NombreDocumental, d.Año
	FROM festival f, documentales d , sepresentaen s
    WHERE s.Festival_idFestival = f.idFestival AND d.idDocumentales = s.Documentales_idDocumentales;	
    
SELECT * FROM VistaFestival WHERE NombreFestival LIKE '%F%' ORDER BY NombreFestival;
SELECT * FROM sepresentaen;

insert into sepresentaen (Documentales_idDocumentales,Festival_idFestival) values (1,1);

ALTER TABLE sepresentaen CHANGE `se presenta en` `SePresentaEn` datatype(length);
RENAME TABLE `se presenta en` TO SePresentaEn;