-- PRIMER STORE PROCEDURE
drop procedure if exists InsertarDatos;
delimiter #
CREATE PROCEDURE InsertarDatos 
(in idDocumentales int, 
Nombre varchar(60), 
Sinopsis varchar(2000), 
Director varchar(45), 
Año year, 
Duración time, 
Colección varchar(45), 
ProyectoEspecial varchar(45), 
Semblanza varchar(2000)
)
begin 
INSERT INTO documentales (idDocumentales, Nombre, Sinopsis, Director, Año, Duración, Colección, ProyectoEspecial, Semblanza) values (idDocumentales, Nombre, Sinopsis, Director, Año, Duración, Colección, ProyectoEspecial, Semblanza);
end#
delimiter ;

Call InsertarDatos (1,'Gueros','In the opening scene, a young mother takes her crying infant outside in a stroller, only to be hit by a water balloon dropped by Tomas from the rooftop of the apartment building. When Tomas mother finds out, she decides to send him to stay with his older brother Sombra, a student in Mexico City, and Sombras roommate Santos. After a bus ride, he arrives at his brothers home late at night. The apartment is dark without electricity. The following morning there is no breakfast.','Alonso Ruizpalacios','2014','106','Contemporanea','Canes','Lorem');
rollback;
use proyectofinal;
SHOW PROCEDURE STATUS;
SHOW CREATE PROCEDURE vistasyprocedures;
select * from documentales where idDocumentales like '%1%';

-- SEGUNDO STORE PROCEDURE
drop procedure if exists PorcentajeDeParticpacion;
delimiter #
CREATE PROCEDURE PorcentajeDeParticipacion()
BEGIN
SELECT a.País_idPaís AS ID, b.nombrePaís AS País ,COUNT(a.País_idPaís) AS DocumentalPorPais, (SELECT count(a.País_idPaís) FROM documentales a) AS TotalDocumentales, (COUNT(a.País_idPaís)/(SELECT count(a.País_idPaís) FROM documentales a))*100 AS PorcentajeParticipacion
FROM documentales a, país b 
WHERE a.País_idPaís=b.idPaís
GROUP BY a.País_idPaís,b.nombrePaís;
END #
DELIMITER ;
Call PorcentajeDeParticipacion;

-- TERCER STORE PROCEDURE
drop procedure if exists BusquedaProduccion;
delimiter #
CREATE PROCEDURE BusquedaProduccion()
BEGIN
SELECT a.idProducción, a.Producción, b.idDocumentales, b.Nombre, b.Sinopsis
FROM produccion a, documentales b 
WHERE a.idProducción=b.Producción_idProducción;
END #
DELIMITER ;
Call BusquedaProduccion;