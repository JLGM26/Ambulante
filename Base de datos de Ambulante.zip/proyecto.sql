-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: localhost    Database: proyectofinal
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cuenta con`
--

DROP TABLE IF EXISTS `cuenta con`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cuenta con` (
  `Documentales_idDocumentales` int NOT NULL,
  `Etiquetas_idEtiquetas` int NOT NULL,
  KEY `fk_Documentales_has_Etiquetas_Etiquetas1_idx` (`Etiquetas_idEtiquetas`),
  KEY `fk_Documentales_has_Etiquetas_Documentales1_idx` (`Documentales_idDocumentales`),
  CONSTRAINT `fk_Documentales_has_Etiquetas_Documentales1` FOREIGN KEY (`Documentales_idDocumentales`) REFERENCES `documentales` (`idDocumentales`),
  CONSTRAINT `fk_Documentales_has_Etiquetas_Etiquetas1` FOREIGN KEY (`Etiquetas_idEtiquetas`) REFERENCES `etiquetas` (`idEtiquetas`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cuenta con`
--

LOCK TABLES `cuenta con` WRITE;
/*!40000 ALTER TABLE `cuenta con` DISABLE KEYS */;
/*!40000 ALTER TABLE `cuenta con` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documentales`
--

DROP TABLE IF EXISTS `documentales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `documentales` (
  `idDocumentales` int NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(60) DEFAULT NULL,
  `Sinopsis` varchar(2000) DEFAULT NULL,
  `Director` varchar(150) DEFAULT NULL,
  `Año` year DEFAULT NULL,
  `Duración` time DEFAULT NULL,
  `Colección` varchar(45) DEFAULT NULL,
  `ProyectoEspecial` varchar(45) DEFAULT NULL,
  `Semblanza` varchar(2000) DEFAULT NULL,
  `Producción_idProducción` int NOT NULL,
  `País_idPaís` int NOT NULL,
  PRIMARY KEY (`idDocumentales`),
  UNIQUE KEY `idDocumentales_UNIQUE` (`idDocumentales`),
  KEY `fk_Documentales_Producción1_idx` (`Producción_idProducción`),
  KEY `fk_Documentales_País1_idx` (`País_idPaís`),
  CONSTRAINT `fk_Documentales_País1` FOREIGN KEY (`País_idPaís`) REFERENCES `país` (`idPaís`),
  CONSTRAINT `fk_Documentales_Producción1` FOREIGN KEY (`Producción_idProducción`) REFERENCES `produccion` (`idProducción`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documentales`
--

LOCK TABLES `documentales` WRITE;
/*!40000 ALTER TABLE `documentales` DISABLE KEYS */;
INSERT INTO `documentales` VALUES (2,'Te nombré en el silencio','Las Rastreadoras de El Fuerte son un grupo de madres de personas desaparecidas en el norte de Sinaloa que, ante la ausencia de las autoridades, salen dos veces a la semana con picos y palas en busca de los restos de sus hijos; un testimonio del abandono del Estado, las agresiones del narco, la indiferencia de la sociedad y el dolor, pero también de la fuerza y valentía que mantiene unidas a estas mujeres, y de su empoderamiento para movilizar a la sociedad en la organización comunitaria.','José María Espinosa',2021,'01:24:00','Festival Rastros y luces','No','José María Espinosa (México, 1989) es fundador de Cinema del Norte, una productora independiente que busca descentralizar y promover la producción cinematográfica en el norte de México. Debutó como guionista y director con el cortometraje Whippet, el cual participó en festivales como el GIFF, Miami Film Festival, Black Canvas FCC y el Festival del Puerto. José X, su segundo cortometraje como director, fue parte de Macabro y Mórbido Film Fest.',1,1),(3,'Expiatorio','Luego de varios meses sin empleo, Mauricio Romero acepta un nuevo trabajo, sin saber que se trata de la transportación de alrededor de 200 cuerpos congelados en un tráiler. El conductor visita las entrañas de un país masacrado y un Estado fallido. Al mismo tiempo, recibe una llamada de su hija, que lo espera a la celebración del primer cumpleaños de su nieto. ','Manuel Acuña',2019,'00:11:00','Festival 2021','No','Manuel Acuña (México) es director y cinefotógrafo. Tiene una licenciatura en Artes Audiovisuales por el ITESO en México y una maestría en Documental por la EICTV en Cuba. Sus cortometrajes han sido exhibidos en México, Estados Unidos, Argentina e India, entre otros países. Actualmente dirige su primer largometraje El silencio en mis manos, el cual ha sido beneficiado por encuentros de creación como el de DocsMX, CC Doc, GoodPitch y Tribeca All Access.',2,2),(4,'Ausencias','Lulú despierta en el silencio de una casa que quedó vacía. La ausencia la hace vivir en un limbo en el que también habitan el deseo, la esperanza y la lucha por encontrar vivos a su esposo y a su hijo Brandon, de ocho años, quienes fueron desaparecidos hace cinco años.','Tatiana Huezo',2015,'00:28:00','Festival','No','Tatiana Huezo (El Salvador, 1972) es directora, fotógrafa y editora. Estudió Cine en el CCC y en la Universidad Pompeu Fabra en Barcelona. Ha sido jurado en festivales como FICUNAM, DocumentaMadrid y el Festival de Cine de Lima. Su primer largometraje documental, El lugar más pequeño, participó en más de cincuenta festivales nacionales e internacionales y obtuvo más de cuarenta reconocimientos. Tempestad, su segundo largo, fue elegido por la AMACC para representar a México en los premios Óscar y los Premios Goya, quedando nominada en estos últimos para competir en la categoría de Mejor Película Iberoamericana. Recientemente dirigió su primera película de ficción, Noche de fuego.',3,3),(5,'No suumbió la eternidad','Dos mujeres esperan a sus familiares desaparecidos. Liliana, quien perdió a su marido en 2010 por responsabilidad del crimen organizado, y Alicia, cuya madre fue desaparecida por el Estado mexicano en la Guerra Sucia en 1978. Las dos historias, distantes entre sí por décadas, se encuentran en este documental para mostrar los conflictos de la memoria y la lucha cotidiana de ambas por no desaparecer de la vida.','Daniela Rea Gómez',2017,'01:13:00','Festival Rastros y luces','No','Daniela Rea Gómez (México, 1981) es periodista y documentalista. Es autora de los libros Nadie les pidió perdón y La tropa, por qué mata un soldado. Ha trabajado en investigación con directores como Everardo González y Ai Weiwei. Impartió talleres sobre investigación documental en la Escuela Internacional de Cine y Televisión, en Cuba. En 2013 recibió el Premio a la Excelencia Periodística, entregado por el PEN International. En 2018 obtuvo el Premio Breach/Valdez de Periodismo y Derechos Humanos que entrega la oficina de la ONU en México, la Agencia France Presse, la Embajada de Francia en México y la Universidad Iberoamericana.',4,4),(6,'Vivos','En septiembre del año pasado se cumplieron cinco años de la muerte y desaparición de estudiantes de la Escuela Normal Rural de Ayotzinapa. Los repetidos intentos de las autoridades en el sexenio anterior por tergiversar la investigación siguen sin rectificarse. Ayotzinapa representa de manera emblemática la colusión entre el Estado y el crimen organizado, así como el impuesto emocional con que se agrava la vida cotidiana en México, plagada de una violencia endémica. Ante la falta de verdad, Vivos recupera el testimonio de los familiares de las víctimas, así como de los defensores y periodistas que han acompañado su lucha en pos de la justicia. Dirigido por el artista contemporáneo chino, Ai Weiwei, quien encontrara en Guerrero ecos de su propio disenso, el documental nos hace partícipes de la actual crisis humanitaria, a través de su punzante fotografía y la intimidad de sus entrevistas. Vivos es un ejercicio de memoria urgente en un país cada vez más impasible frente a su propia tragedia. ','Ai Weiwei',2019,'01:52:00','Festival 2020','No','Ai Weiwei (China, 1957) es un artista contemporáneo, activista y director de cine. Conocido principalmente por su trabajo artístico con una fuerte carga política y de crítica social. Weiwei utiliza una amplia gama de medios para llegar a su público, por ello ha realizado numerosos documentales sobre cuestiones sociales y políticas que se han presentado en los principales festivales de cine del mundo.\n\n ',5,5),(7,'¿Qué les pasó a las abejas','“Nosotros somos mayas, pero necesitamos que nos vean como personas”, dice uno de los indígenas involucrados en la defensa del territorio de Hopelchén, Campeche, frente a la violenta inserción de empresas como Monsanto en sus territorios. ¿Qué les pasó a las abejas? desenmascara los privilegios de los corporativos trasnacionales y muestra los efectos del capitalismo en las estructuras sociales y ecológicas de las comunidades indígenas en México. El problema comienza en 2012, cuando millones de abejas murieron a causa de los pesticidas y herbicidas empleados en la siembra de soya transgénica en Campeche, a manos de la compañía Monsanto, pionera en la modificación genética de células vegetales. Conscientes de los efectos que tiene la muerte de estos insectos en el medio ambiente y en la preservación de la biodiversidad, las comunidades mayas —lideradas por Gustavo Huchin y Leydi Pech, protagonistas del documental— enfrentaron a las autoridades y a las comunidades menonitas vecinas para detener la siembra de semillas transgénicas en su territorio. En su lucha se evidencian los contrastes entre los métodos tradicionales, sustentables y respetuosos del ecosistema, y el trabajo industrial que amenaza con modificar la vida como la conocemos hasta ahora.','Adriana Otero, Robin Canul',2019,'01:07:00','Festival 2020','No','Adriana Otero Puerto (México, 1989) es productora y directora. Es egresada de la maestría en Producción y Enseñanza de Artes Visuales de la Escuela Superior de Artes de Yucatán y fue alumna de la segunda y tercera generación de Ambulante Más Allá de Documental Ambulante A.C.\n\nRobin Canul Suárez (México, 1985) es periodista y fotógrafo profesional, ha colaborado con la revista Tierra Adentro y en libros del Consejo Nacional para la Cultura y las Artes. ¿Qué les pasó a las abejas? es su ópera prima, donde fungió como codirector y fotógrafo.\n\n ',6,6),(8,'Birth Wars','Birth Wars documenta la actividad de las parteras en cuatro estados del sureste de México: Guerrero, Veracruz, Oaxaca y Chiapas. Tlapa de Comonfort o Acatepec, por ejemplo, son escenarios donde el descuido del sector público de salud alcanza el ámbito de la maternidad. En muchos casos, las embarazadas enfrentan restricciones para elegir entre una cesárea o un parto natural; además, la violencia obstétrica se perfila alarmante. \n\nJanet Jarman muestra cómo los problemas relativos a la partería corresponden, principalmente, a la falta de vínculos entre esta profesión y el personal de las clínicas. Por si fuera poco, varios médicos subestiman el trabajo de las parteras haciendo aún más difícil la labor de traer nuevos seres humanos al mundo en comunidades lejanas. Enfatizando en las situaciones enfrentadas por Rafaela, una joven partera de Guerrero, Jarman ofrece una reflexión que retoma lo dicho por Michel Odent: “Para cambiar el mundo primero hay que cambiar la forma de nacer”.','Janet Jarman',2019,'01:13:00','Festival 2020','Sí','Janet Jarman es fotoperiodista y documentalista. Comenzó su carrera en Estados Unidos y Londres. Desde 2003 reside en México, donde se centra en temas como los problemas de seguridad, la migración, el acceso a la atención médica y los desafíos de los recursos hídricos. El trabajo de Jarman se ha publicado en The New York Times, National Geographic y Smithsonian Magazine, entre otros. También ha colaborado con fundaciones y algunas ONG. Sus fotografías se han presentado en Visa Pour l’Image y han recibido diversos reconocimientos.',7,7),(9,'Anina','Anina Yatay Salas es una niña de diez años. Su nombre es un palíndromo, se lee igual al derecho que al revés, y esto provoca las risas de algunos de sus compañeros de escuela, en particular de Yisel. Anina vivirá aventuras y aprendizajes vitales en esta comedia sobre la amistad y la empatía.','Alfredo Soderguit',2013,'01:18:00','Festival 2018','No','Alfredo Soderguit (Uruguay, 1973) es ilustrador. Ha ilustrado más de cuarenta libros en Uruguay, Argentina, Noruega y México. Ilustró la novela Anina Yatay Salas de Sergio López Suárez, libro que lo inspiró para hacer la película Anina, su ópera prima y hasta el momento, su única cinta como director. ',8,8),(10,'A los once','Isa y Zoe tienen once años, son mejores amigas y sus personalidades activas y divertidas las unen haciendo deportes como hapkido (arte marcial coreano) y voleibol. Entre risas, abrazos y secretos, nos adentramos en sus vidas y vemos cómo ellas descubren el mundo.  A través de sus videodiarios, ellas dan cuenta de sus perspectivas acerca del tránsito de la infancia a la adolescencia, de los cambios que están viviendo y de sus inquietudes al dejar de ser niñas para convertirse en mujeres. Con el apoyo mutuo y el de sus padres logran recorrer las vicisitudes de la pubertad. A los once es un testimonio fresco y honesto sobre la amistad y una exploración de lo que significa la aventura de crecer.','Carolina Admirable García, Zahira Aldana Ramírez, Nancy Samara Guerrero Miranda, Maria Fernanda Islas Montero y Aldo Alejandro Ter-veen Calderón ',2020,'00:21:00','Festival 2020','No','Carolina Admirable García (España, 1993) es una artista plástica que ha encontrado en el arte contemporáneo una herramienta para el cambio social, pero que la curiosidad la condujo a Ambulante Más Allá donde encontró nuevas formas de expresarse a través del cine.',9,9),(11,'Con Brío','Las flores abandonan su sitio para saltar por el jardín, empezando un recorrido donde la alegría adquiere distintos tonos y texturas. La composición del color y la música se entrelazan, jugando con los ojos del espectador. En una atmósfera casi onírica, las plantas se mueven guiadas por el chelo, el ukulele y el violín.','Sandra Eber',2012,'00:04:00','Festival 2020','No','Sandra Eber es cineasta de animación con intereses multidisciplinarios que la han llevado a tener una extensa carrera como desarrolladora de software. Actualmente da clases en el Programa de Animación Cinematográfica en la Escuela de Cine Mel Hoppenheim en Montreal, Canadá.',10,10),(12,'Yermo','El séptimo largometraje de Everardo González nos conduce a una exploración estética de la vida en varios desiertos del mundo: México, Mongolia, India, Estados Unidos, Perú, Islandia, Namibia, Marruecos y Chile. Se trata de un documental de autor con una propuesta formal de vanguardia. La música, cercana al tango, anima paisajes surrealistas y crea atmósferas envolventes. Filmado en gran parte solo por el director, sin un guion preconcebido y con una apertura total a las interacciones culturales, captura la vida cotidiana de diferentes pueblos: conversaciones casuales, rituales, performances y procesos creativos, pero también revela los desencuentros suscitados sobre todo por las barreras del lenguaje. La inquietud central, que remite al cine etnográfico clásico, es la adaptación a un entorno yermo y los recursos culturales que la posibilitan. Así resurge la vieja pregunta por la identidad y la alteridad, por lo familar y lo extraño, echando nueva luz sobre la diversidad cultural, experimentando con frescura las complejidades de la interculturalidad.','Everardo González',2020,'01:15:00','Festival 2020','Sí','Everardo González (Estados Unidos, 1971) es un director mexicano cuya obra se considera de las más sólidas de América Latina. Su trabajo se caracteriza por la inquietud de plasmar problemáticas sociales y situaciones cotidianas, todo dentro de un mismo plano. Sus filmes se han exhibido en festivales como el IDFA, El Festival Internacional de Cine de Locarno, el BAFICI, el Festival Internacional de Cine de Guadalajara y el FICM.',11,11),(13,'¿Me vas a gritar?','La violencia y los juicios hacia las mujeres son los elementos que cargan las pesas que Melissa levanta en sus entrenamientos. En una sociedad machista, ella rompe con el rol femenino y enfrenta la exigencia, el acoso y la culpa en la calle y en el ring.','Laura Herrero Garvín',2018,'00:11:00','Festival 2019','No','Laura Herrero Garvín (España, 1985) es una cineasta que llegó a México en 2010 para estudiar cine y trabajar como directora, cinefotógrafa y montadora en diferentes proyectos documentales. Ha realizado más de una veintena de cortometrajes documentales en diferentes países, una gran variedad de videos y campañas de incidencia con una perspectiva transversal de género. Es integrante de la asociación audiovisual La Sandía Digital, cuyo objetivo es la reestructuración del tejido social y la defensa de los derechos humanos a través del cine.',12,12),(14,'Amicus','Un niño de la calle que vende galletas encuentra un gatito abandonado. Su generosidad será recompensada con el cariño y lealtad del felino. Juntos enfrentarán la apatía citadina compartiendo el afecto y la diversión que por sí solos nunca conocieron.','Raul “Robin” Morales ',2014,'00:05:00','Festival 2019','No','Raúl “Robin” Morales (México) es autor, diseñador, músico, bailarín y cineasta. Su película El trompetista recibió apoyo del Imcine, y su obra Las piezas del rompecabezas fue el primer filme original de Canal Once. En 2017 ganó la Residencia Folimage con su última película El tigre sin rayas. ',13,13),(15,'Acuarela','La nueva película de Victor Kossakovsky es una sacudida al ser humano para que se dé cuenta de su pequeñez ante la fuerza y la voluntad del recurso natural más preciado: el agua. Acuarela es una impactante visualización de las múltiples personalidades del agua.','Victor Kossakovsky',2018,'01:30:00','Destival 2019','No',NULL,14,14),(16,'Algo quema','Alfredo Ovando Candía, exmilitar boliviano, ejerció la presidencia de su país en dos ocasiones. Figura controversial, se involucró en la modernización de Bolivia, pero también en actos represivos como la masacre de San Juan, en 1967, en la que el Ejército asaltó campamentos mineros dejando decenas de víctimas mortales. Medio siglo más tarde, su nieto decide indagar en los recuerdos familiares y archivos públicos para resolver el enigma de su existencia: ¿qué yace en medio del abuelo amoroso y el político inescrupuloso?\n\nCon pocos recursos tales como rollos caseros de super 8, noticieros de la época, conversaciones con sus parientes —resalta la voz afable del padre del cineasta y el dolor contenido de su prima—, Ovando logra un filme conmovedor, íntegro y revelador sobre el peso del afecto y la  sombra de las dictaduras latinoamericanas que aún ensombrece nuestra memoria. ','Mauricio Ovando',2018,'01:17:00','Festival 2019','No',NULL,15,15),(17,'People of Wind and Sea','The story of two communities in the Tehuantepec Isthmus, Álvaro Obregón, a fishing community, and La Venta, a farming community and of their struggle to resist the assault of transnational wind power companies.','Ingrid Eunice Fabián González',2016,'01:14:00','Festival 2017','Sí','Keith Maitland (Estados Unidos) es un director de documentales, comerciales y programas de televisión nominado a los Emmy. Fue asistente de dirección durante siete temporadas en la serie La ley y el orden. Estudió en la Universidad de Texas, el Director’s Guild of America Trainee Program y en la PBS Producer’s Academy',16,16),(18,'Beach Flags','Vida es una joven salvavidas iraní determinada en participar en una competencia internacional en Australia, pero cuando Sareh, tan talentosa como ella, se une al equipo, todo cambia.','Sarah Saidan',2014,'00:13:00','Sundace ','No','Sarah Saidan (Irán, 1978) es animadora y directora de cine. Estudió Diseño Gráfico en Irán y Dirección de Cine en La Poudrière en Francia. En 2011 comenzó a trabajar en Banderas de playa, una película producida por Sacrebleu Productions and Folimage.',17,17),(19,'Bilingüe','El filme comienza con la ejecución de un performance en Alemania, con la participación de tres músicos argentinos –procedentes de una comunidad Wichí–, entre otros. Grabado en Berlín y en la provincia norteña de Salta, el vídeo reconoce como el lenguaje, el gesto, el ritual y el espectáculo son materia para las diferentes formas de la traducción cultural.','Leticia Obeid',2013,'00:26:00','Festival 2017 ','No','Leticia Obeid (Argentina, 1975) estudió pintura en la Escuela de Artes de la Universidad Nacional de Córdoba, y ha realizado residencias artísticas en instituciones como el Atlantic Center for the Arts, E.U. (2001), Cité International des Arts, París (2007) y Casa Vecina, México(2011). Su trabajo ha sido exhibido en exposiciones colectivas e individuales a lo largo de países como Alemania, Turquía, España, Países Bajos e Italia. También es autora de dos novelas, editadas bajo el sello de Editorial Caballo Negro, Córdoba.',18,18),(20,'Cambio de Amigo','Un gallito de bádminton ha caído en la esquina del campo de juego. Un pajarito que pasa por ahí confunde al gallito con su amigo.','Mehdi Alibeygi',2014,'00:02:00','Festival 2017','No','Mehdi Alibeygi (Irán, 1984) es monero, ilustrador, artista de cómic y animador. Estudió Diseño Gráfico. Desde 2010 trabaja en el estudio de cómics Aria, y desde 2013 trabaja como animador, diseñador y director en el estudio Raiavin.',19,19),(21,'Chavela','A través de una entrevista nunca antes vista, realizada 20 años antes de su muerte en 2012, y guiada por las historias de sus canciones, esta película retrata a la mujer que se atrevió a vivir como quiso: Chavela Vargas.','Catherine Gund, Daresha Kyi',2017,'01:33:00','Festival 2017 ','Sí','Catherine Gund (Australia, 1965) es una activista y directora de cine documental, además de ser fundadora de Aubin Pictures, productora cuyos temas transitan desde las relaciones raciales hasta la protección del medio ambiente, pasando por la diversidad sexual, los derechos reproductivos, y la lucha contra el VIH. Su trabajo ha sido nominado a los Emmy, y su labor social es reconocida desde diversas organizaciones y grupos minoritarios.\n\n\nDaresha Kyi (Estados Unidos 1962) es una guionista, directora y productora de cine documental y programas para televisión. Su cortometraje Land Where My Fathers Died, realizado en su totalidad junto a Isaiah Washington, fue patrocinado por el Programa de Directores del Instituto Americano de Cine. Colaboró como codirectora y coproductora en la filmación del documental Chavela.\n\nTambién trabaja en Aubin Pictures, en donde produjo Dispatches from Cleveland.',20,20),(22,'October 2nd: This is Mexico','A chronological account of the events that culminated in the 1968 student massacre of Tlatelolco, this film intertwines recordings of the protests with still photographs, accompanied by the voice of a narrator who questions the spectator. Thus, it represents the possibility of communicating what happened inside the student movement to a general audience, as conventional media showed a very unrealistic version of this period.','Óscar Menéndez',1970,'00:55:00','Festival 2018 ','Sí','Óscar Menéndez is a photographer and a fiction and documentary filmmaker. His work stands out for tackling social issues, through films such as México Bárbaro, – inspired in the homonymous book by John Kenneth Turner – Únete pueblo and Historia de un documento.',21,21),(24,'Hasta los dientes','En 2010, el Gobierno mexicano anunció la muerte de dos supuestos sicarios armados hasta los dientes, pero en realidad se trataba de dos alumnos de excelencia del Tecnológico de Monterrey, quienes fueron torturados y asesinados por militares. ','Alberto Arnaut ',2018,'01:48:00','Movies That Matter','Sí','Alberto Arnaut es egresado de Comunicación Social de la Universidad Autónoma Metropolitana, donde se especializó en Cine Documental. Actualmente se encuentra cursando la Maestría en Cine Documental del Centro Universitario de Estudios Cinematográficos. Hasta los dientes es su ópera prima.',22,22),(25,'Abuelita','Conmovedora reflexión en voz de una nieta sobre la vida de su abuelita, quien decide vivir de espaldas al mar por miedo al agua, y que parece ignorar a todos sus nietos; se trata de un acercamiento a la complejidad de las emociones y las relaciones familiares.','Janice  Nadeau',2016,'00:06:00','International Animated Film Festival','No','Janice Nadeau es ilustradora, directora de arte y animadora. Estudió Diseño Gráfico en la Universidad de Quebec en Montreal e Ilustración en la Escuela de Arte en Estrasburgo. Ha ilustrado múltiples libros y recibió tres veces el Governor General’s Awards por su trabajo.',23,23),(26,'Bätsi','Acercamiento a la cotidianidad de una escuela primaria en El Rincón de San Ildefonso, en Amealco, Querétaro; ilustra la tradición folclórica en la que se desenvuelven los niños de esta comunidad, así como las dificultades educativas y sociales que enfrentan.','Brenda Ávila, Alma Rojo',2017,'00:12:00','Festival de cine Latinoamericano ','No','Brenda Ávila estudió Sociología y Comunicación Audiovisual en la Universidad Autónoma de Querétaro. Ha colaborado en diversos medios como el periódico A.M. Querétaro y la revista CINEFILA. Participó en la producción del largometraje queretano Revueltas, y asistió al diplomado Estudios de sociología contemporánea en praxis visual y realidad latinoamericana. Actualmente se desempeña como docente de sociología del arte en el CENADAC y trabaja como conductora para proyectos de televisión e internet.',24,24),(27,'Blind','La Alabama School for the Blind es una institución dedicada a fomentar que las personas invidentes y débiles visuales logren independencia en su vida. Ciegosretrata sus programas educativos, los cuales incluyen asignaturas tradicionales, terapia psicológica y actividades deportivas, entre otros.\n\n','Frederick Wiseman ',1986,'01:47:00','BFI London ','No','Frederick Wiseman (Boston, 1930) es un aclamado director de cine cuyos trabajos se distinguen por su particular manera de retratar la realidad. A lo largo de sus más de cuarenta películas en cincuenta años de producción, Wiseman ha explorado diversas instituciones y espacios clave en la cultura occidental, y ha profundizado en la naturaleza del ser humano al mostrar la sociedad desde una amplia gama ética y existencial. .',25,25),(28,'Becoming Who I Was','Un niño aparentemente ordinario descubre que es el monje tibetano de más alto rango reencarnado de un pasado, lo que le confiere el noble título de Rinpoche. Desplazado en su reencarnación en Ladakh, debido a la inestabilidad política en el Tíbet, está separado de su antiguo monasterio. Durante siete años, la cámara acompaña al joven reencarnado y a su anciano padrino, en un viaje peligroso por las profundidades de los Himalayas para encontrar su lugar en el mundo, y los enfrenta a preguntas sobre la supervivencia, la madurez y el servicio de una orden sagrada.','Chang-Yong Moon, Jin Jeon',2016,'01:36:00','Berlinale ','No','Chang-Yong Moon es director y cinematógrafo surcoreano, desde 1998 ha trabajado en documentales y ha ganado numerosos premios por sus programas de televisión, incluido el Premio por Excelencia del Korean Broadcasting System. \nJin Jeon es productora y directora. Creció en cuatro países diferentes. Cursó una maestría en Periodismo por la Universidad de Cape Town, trabajó cinco años como directora y productora en la televisión sudafricana y actualmente produce documentales para emisoras en Corea del Sur.',26,26),(29,'England Is Mine','Filme de ficción que retrata a Steven Patrick Morrissey —mejor conocido como Morrissey— en su camino para convertirse en el líder de la banda The Smiths durante los años setenta; expone las influencias creativas y las inseguridades del músico inglés.','Mark Gill ',2017,'01:34:00','British Film Festival  ','No','Mark Gill es un director de Inglaterra. Ha recibido reconocimientos como el otorgado por la Royal Television Society, además de una nominación al Óscar y otra al BAFTA.',27,27),(30,'El reino de la sirena','El límite entre la tierra y el mar es mágico. Como las sirenas que, según cuentan, son peces del vientre hacia abajo. En torno a estas criaturas hay muchas otras leyendas. Por ejemplo, que son dueñas del agua y ofrecen grandes banquetes en el fondo del mar para los hombres a quienes enamoran; pero los habitantes de Bilwi, un pueblo de pescadores en Nicaragua, parecen haber perdido el favor de las sirenas: los buzos descienden al fondo del mar y regresan con el cuerpo paralizado a una tierra dominada por una violencia latente. Luis Rincón explora la vida en este límite, por encima y por debajo del mar, con sombras que reflejan escamas de pescado sobre la piel de sus habitantes; un lugar donde los conflictos conviven con la belleza del espacio.','Luis Rincón ',2017,'01:18:00','FICUNAM ','No','Luis Rincón (México, 1981) estudió Comunicación en la Universidad Iberoamericana. Obtuvo apoyo del FONCA por su proyecto México bárbaro 2010. Su largometraje documental El árbol olvidado obtuvo una nominación en los premios Ariel y fue ganador del reconocimiento a Mejor Largometraje Documental Mexicano en DocsMx.',28,28),(31,'Hilos','En una especie de danza sin palabras, Tråder ilustra la íntima relación que existe entre una madre y su hija. Una tierna explicación de cómo los lazos familiares pueden moldearse para acompañarnos en cada momento de la vida.','Torill Kove',2017,'00:09:00','The Norwegian Short Film Festival  ','No','Torill Kove es directora y animadora. Estudió Planeación Urbana en la Universidad Concordia  para luego especializarse en Animación en la Universidad McGill. Su pasión por la animación nació cuando ella tenía 30 años y le dio un giro radical a su carrera. Desde entonces ha recibido numerosos reconocimientos que incluyen el premio Óscar a Mejor Cortometraje Animado por The Danish Poet.',29,29),(32,'Los herederos','Explora la rutina de los niños mexicanos que, desde pequeños, deben trabajar en el campo junto con sus familias; un retrato de la lucha diaria por sobrevivir en una realidad que se repite generación tras generación.','Eugenio Polgovsky',2008,'01:30:00','Berlinale ','Sí','Eugenio Polgovsky dedicó su obra cinematográfica y audiovisual a los habitantes del México rural y al estudio de las fronteras entre la naturaleza y la civilización moderna. Recibió cuatro premios Ariel, el fondo Hubert Bals del Festival de Cine de Róterdam, el Premio José Rovirosa UNAM y el Premio Joris Ivens del festival Cinéma du Réel, entre más de treinta reconocimientos internacionales.',30,30);
/*!40000 ALTER TABLE `documentales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `etiquetas`
--

DROP TABLE IF EXISTS `etiquetas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `etiquetas` (
  `idEtiquetas` int NOT NULL AUTO_INCREMENT,
  `Nombreetiqueta` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`idEtiquetas`),
  UNIQUE KEY `idEtiquetas_UNIQUE` (`idEtiquetas`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `etiquetas`
--

LOCK TABLES `etiquetas` WRITE;
/*!40000 ALTER TABLE `etiquetas` DISABLE KEYS */;
INSERT INTO `etiquetas` VALUES (1,'Desapariciones, Justicia, Memoria Social'),(2,'Desapariciones, Justicia, Memoria Social'),(3,'Desapariciones, Justicia, Memoria Social'),(4,'Desapariciones, Justicia, Memoria Social'),(5,'Resistencias, Ambulante en Casa, Artes, Conflictos sociales'),(6,'Educación, Medio Ambiente, Memoria Social'),(7,'Culturas y Pueblos Ancestrales, Resistencia, Familia'),(8,'Animación, Niñez, Biográfico'),(9,'Ambulante Más Allá, Familia, Niñez'),(10,'Familia, Medio Ambiente, Niñez'),(11,'Pulsos, Artes, Conflictos Sociales'),(12,'Violencia, Género, Política'),(13,'Animación, Gira, NIñez'),(14,'Intersecciones, Gira, Medio Ambiente'),(15,'Conflictos Sociales, Memoria Social, LatinoAmérica'),(16,'Conflictos Sociales, Medio Ambiente, Cultura y Pueblos Ancestrales '),(17,'Género, Deporte, Ambulantito'),(18,'Ambulantito'),(19,'Ambulantito'),(20,'Biográfico, Música, Proyecciones Especiales'),(21,'Conflictos Sociales, Memoria Social, México'),(22,'Biográfico, Conflictos Sociales, Justicia, Política'),(23,'Animación, Familia,  Niñez'),(24,'Educación, Culturas y Pueblos Ancestrales, Niñez'),(25,'Discapacidad, Retrospectiva, Niñez'),(26,'Aquí/Ahora'),(27,'Música, Cultura'),(28,'Medio Ambiente, Violencia, Conflictos Sociales'),(29,'Animación, Biográfico, NIñez'),(30,'Proyecciones Especiales');
/*!40000 ALTER TABLE `etiquetas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `festival`
--

DROP TABLE IF EXISTS `festival`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `festival` (
  `idFestival` int NOT NULL AUTO_INCREMENT,
  `NombreFestival` varchar(60) DEFAULT NULL,
  `Fecha` date DEFAULT NULL,
  PRIMARY KEY (`idFestival`),
  UNIQUE KEY `idFestival_UNIQUE` (`idFestival`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `festival`
--

LOCK TABLES `festival` WRITE;
/*!40000 ALTER TABLE `festival` DISABLE KEYS */;
INSERT INTO `festival` VALUES (1,'FESTIVAL 2021','2020-08-15'),(2,'Festival Internacional de Cine de Guanajuato','2021-09-15'),(3,'Festival Internacional de Cine de Morelia','2015-07-15'),(4,'DocsMX','2018-06-22'),(5,'New Zealand International Film Festival','2020-09-15'),(6,'Festival Kayche','2020-06-27'),(7,'Festival de Cine de la Habana','2020-11-14'),(8,'Festival Internacional de Cine de San Sebastián','2018-06-02'),(9,NULL,'2020-02-26'),(10,'WNDX Festival de Imagen y Movimiento','2020-10-02'),(11,NULL,'2020-07-11'),(12,'FICM','2019-08-02'),(13,'Children’s Film Festival Seattle','2019-09-15'),(14,'Antenna Festival ','2019-06-22'),(15,NULL,'2018-05-10'),(16,'Festival Internacional de Cine de Seattle','2017-06-01'),(17,'Festival Fránces de Cine','2017-05-17'),(18,'Festival Internacional de Cortometraje de Clermont-Ferrand','2017-09-11'),(19,'Festival Internacional de Cine de Animación de Annecy','2017-07-01'),(20,'Berlinale','2017-04-22'),(21,NULL,'2018-10-02'),(22,'Children’s Film Festival Seattle','2018-06-22'),(23,'International Animated Film Festival','2018-05-12'),(24,'Festival 2018','2018-10-03'),(25,'Festival Internacional de Cine de Bombay','2018-04-30'),(26,'SIFF','2018-01-22'),(27,'British Film Festival','2017-03-05'),(28,'DOK Leipzig','2018-11-07'),(29,'Toronto International Film Festival','2018-09-05'),(30,'Mostra de Venezia, Orrizontti','2018-12-04');
/*!40000 ALTER TABLE `festival` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `idioma`
--

DROP TABLE IF EXISTS `idioma`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `idioma` (
  `idIdioma` int NOT NULL AUTO_INCREMENT,
  `IdiomaUsado` varchar(100) DEFAULT NULL,
  `Documentales_idDocumentales` int NOT NULL,
  PRIMARY KEY (`idIdioma`),
  KEY `fk_Idioma_Documentales1_idx` (`Documentales_idDocumentales`),
  CONSTRAINT `fk_Idioma_Documentales1` FOREIGN KEY (`Documentales_idDocumentales`) REFERENCES `documentales` (`idDocumentales`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `idioma`
--

LOCK TABLES `idioma` WRITE;
/*!40000 ALTER TABLE `idioma` DISABLE KEYS */;
INSERT INTO `idioma` VALUES (1,'Español',2),(2,'Español',3),(3,'Español',4),(4,'Inglés, Español',5),(5,'Español, Maya',6),(6,'Español, Tseltal',7),(7,'Español',8),(8,'Español',9),(9,'Sin Idioma',10),(10,'Español, inglés, mongol, navajo, árabe, hindi, kalbelia, bereber, otjihimba, khoekhoegowab',11),(11,'Español',12),(12,'Sin Diálogos',13),(13,'Ruso, inglés, español',14),(14,'Español',15),(15,'Inglés, Español',16),(16,'Fránces,Español',17),(17,'Español',18),(18,'Sin Diálogos',19),(19,'Español',20),(20,'Español',22),(21,'Español, Inglés',21),(22,'Español',24),(23,'Inglés, Espñaol',25),(24,'Español, Otomí',26),(25,'Inglés',27),(26,'Ladakhi, tibetano, hindi',28),(27,'Inglés',29),(28,'Español, Misquito',30),(29,'Sin Diálogos',31),(30,'Español',32);
/*!40000 ALTER TABLE `idioma` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `país`
--

DROP TABLE IF EXISTS `país`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `país` (
  `idPaís` int NOT NULL AUTO_INCREMENT,
  `NombrePaís` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`idPaís`),
  UNIQUE KEY `idPaís_UNIQUE` (`idPaís`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `país`
--

LOCK TABLES `país` WRITE;
/*!40000 ALTER TABLE `país` DISABLE KEYS */;
INSERT INTO `país` VALUES (1,'México'),(2,'México, Cuba'),(3,'México, Salvador'),(4,'México'),(5,'Alemania, México'),(6,'México'),(7,'México'),(8,'Uruguay, Colombia'),(9,'México'),(10,'Cánada'),(11,'México'),(12,'México'),(13,'México'),(14,'Reino Unido, Alemania, Dinamarca, Estados Unidos'),(15,'Bolivia'),(16,'USA, México'),(17,'Francia'),(18,'Argentina'),(19,'Irán'),(20,'México'),(21,'México, Estados Unidos'),(22,'México'),(23,'Cánada'),(24,'México'),(25,'Estados Unidos'),(26,'Corea del Sur'),(27,'Reino Unido/Inglaterra'),(28,'México'),(29,'Noruega'),(30,'México');
/*!40000 ALTER TABLE `país` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `produccion`
--

DROP TABLE IF EXISTS `produccion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `produccion` (
  `idProducción` int NOT NULL AUTO_INCREMENT,
  `Fotografía` varchar(100) DEFAULT NULL,
  `Guion` varchar(80) DEFAULT NULL,
  `Edición` varchar(200) DEFAULT NULL,
  `Sonido` varchar(200) DEFAULT NULL,
  `Música` varchar(100) DEFAULT NULL,
  `Producción` varchar(200) DEFAULT NULL,
  `CampañaProductora` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`idProducción`),
  UNIQUE KEY `idProducción_UNIQUE` (`idProducción`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produccion`
--

LOCK TABLES `produccion` WRITE;
/*!40000 ALTER TABLE `produccion` DISABLE KEYS */;
INSERT INTO `produccion` VALUES (1,'Daniel Zúñiga','José María Espinosa','Horacio Romo Mercado','Martín Hernández, Alejandro Quevedo, Luis Gil Silva','Quincas Moreira','Paloma Cabrera, Juan Pablo Espinosa, Ixchel Cisneros, Elena Fortes, Daniela Alatorre, Luis Sosa, Sam Patillo','EMT Films, Cinema del Norte, No Ficción'),(2,'Manuel Acuña','Manuel Acuña','Manuel Acuña','Rubí J. Pérez',NULL,'Manuel Acuña','Contratiempo Cine'),(3,'Ernesto Pardo','Tatiana Huezo','Lucrecia Gutiérrez Maupomé','Pablo Tamez',NULL,'Anïs Vignal, Julio López Fernández','La Sandía Digital (México), Trípode Audiovisual (El Salvador)'),(4,'Gabriel Villegas','Daniela Rea Gómez','Mariano V. Osnaya','Guillermo Llaguno','Leoncio Lara Bon','Mario Gutiérrez Vega','ARTEGIOS, PAN O RAMA'),(5,'Ernesto Pardo, Carlos F. Rossini, Bruno Santamaría, Ai Weiwei, Ma Yan',NULL,'Niels Pagh Andersen','Henrik Garnov','Jens Bjørnkjær','Ai Weiwei, Daniela Alatorre, Elena Fortes','Ai Weiwei Studio, No Ficción'),(6,'Maricarmen Sordo Aguilar, Robin Canul Suárez','Adriana Otero','Jairo Mukul Alcocer','Alberto Palomo Torres','Alberto Palomo Torres','Adriana Otero','Caja Negra, FOPROCINE, IMCINE'),(7,NULL,NULL,'Filip Lein','Maria Cristina Santos Monroy, Emma Viviana Gonzalez y Myriam Valdez Soto','Carlos ‘Lion’ Perez','Janet Jarman, Filip Lein','Tonala Productions'),(8,'Juan Carve','Federico Ivanier','Julián Goyoaga, Germán Tejeira','Gastón Otero, Bruno Boselli',NULL,'Germán Tejeira, Julián Goyoaga, Alfredo Soderguit, Alejo Schettini, Jhonny Hendrix','Rain Dogs Cine, Palermo Estudio, Antorcha Films'),(9,'Nancy Samara Guerrero Miranda','Aldo Alejandro Ter-veen Calderón, Carolina Admirable García','Aldo Alejandro Ter-veen Calderón, Carolina Admirable García','Zahira Aldana Ramírez',NULL,'Nancy Samara Guerrero Miranda','Ambulante Más Allá'),(10,NULL,NULL,NULL,'Shelley Craig','James Hill',NULL,NULL),(11,'Everardo González','Everardo González','Paloma López Carrillo','Matías Barberis','Raúl Vizzi','Inna Payán, Roberto Garza, Alfredo de Stéfano','Artegios, Animal de luz'),(12,'Laura Herrero Garvín','Laura Herrero Garvín, Majo Sisca','Eduardo Palenque','Eloísa Díez','Batallones Femeninos','Laura Herrero Garvín','Laura Herrero Garvín'),(13,NULL,'Raúl “Robin” Morales','Javier Pérez',NULL,'Yair Hernández','Lorelei Rodríguez','Canal 22'),(14,'Victor Kossakovsky, Ben Bernhard','Victor Kossakovsky, Aimara Reques','Victor Kossakovsky, Molly Malene Stensgaard, Ainara Vera','Alexander Dudarev','Eicca Toppinen','Aimara Reques, Heino Deckert, Sigrid Dyekjær','Aconite Productions, ma.ja.de Filmproduktion, Danish Documentary'),(15,'Mauricio Ovando','Mauricio Alfredo Ovando','Cecilia Almeida Saquieres','Ajayus de Antaño',NULL,'Juan Alvarez Durán','Nicobis, Artes Andes Américas'),(16,'Pablo García Morales','Ingrid Eunice Fabián González','Jorge Ángel Pérez, Martha Uc','Jorge Ángel Pérez','Cuauhtémoc Carlos Ríos Hernández','Ingrid Eunice Fabián González, Jorge Ángel Pérez, Félix Santiago Montero, Cristina Valle, María Inés Roqué, Carolina Coppel','Compañía productora'),(17,'Sarah Saidan','Sarah Saidan','Hervé Guichard','Lionel Guenoun','Yan Volsy','Ron Dyens','Sacrebleu Productions'),(18,'Leticia Obeid','Leticia Obeid','Leticia Obeid','Leticia Obeid','Leticia Obeid','Leticia Obeid','Independiente'),(19,'Mehdi Alibeygi','Mehdi Alibeygi','Mehdi Alibeygi','Hani Rajabi','Hani Rajabi','Mehdi Alibeygi','Mehdi Alibeygi'),(20,'Catherine Gund, Natalia Cuevas, Paula Gutiérrez Orío','Catherine Gund, Daresha Kyi','Carla Gutiérrez','Gil Talmi','Gil Talmi','Catherine Gund, Daresha Kyi, Lynda Weinman, Bruce Heavin','Independiente'),(21,'Óscar Menéndez','Óscar Menéndez','Óscar Menéndez','Óscar Menéndez','Óscar Menéndez','Óscar Menéndez','Independiente'),(22,'Jaiziel Hernández','Alberto Arnaut ','Pedro G. García','Daniel Touron','Carlo Ayhllón','Erick García Corona','IMCINE-FOPROCINE, Hasta los Dientes Films S.A. de C.V., Chemistry Cine'),(23,'Janice Nadeau','Janice Nadeau','Herve Guichard ','Olivier Calvert ','Benoit Charest, Benoit Groulx, Sylvain Murray','Corinne Destombes, Marc Bertrand, Julie Roy ','National Film Board of Canada'),(24,'Brenda Ávila, Alma Rojo, Diego Goeury','Brenda Ávila, Alma Rojo, Diego Goeury','Diego Goeury, Alma Rojo','Diego Goeury, Brenda Ávila','Andrés Espinosa Lámbarri','Brenda Ávila, Alma Rojo, Diego Goeury','Independiente'),(25,'Jonh Davey','Frederick Wiseman','Frederick Wiseman','Frederick Wiseman','Frederick Wiseman','Frederick Wiseman','Zipporah Films'),(26,'Chang-Yong Moon, Jin Jeon','Chang-Yong Moon, Jin Jeon','Chang-Yong Moon, Jin Jeon','Chang-Yong Moon, Jin Jeon','Jung-Li Seo','Chang-Yong Moon, Jin Jeon','Sonamu Films, Prosum Inc.'),(27,'Nic Knowland','Mark Gill, William Thacker','Adam Biskupski','Ian Neil','Ian Neil','Baldwin Li, Orian Williams ','Honlodge'),(28,'Juan Pablo Ramírez Ibañez ','Luis Rincón','Lucrecia Gutiérrez Maupomé','Bernat Fortiana','Bernat Fortiana','Cristina Velasco, Bruno Cárcamo, Rigoberto Perezcano','Paloma Negra Films, IMCINE'),(29,'Torill Kove','Torill Kove','Simen Gengenbach, Serge Verreault','Luigi Allemano','Kevin Dean ','Lise Fearnley, Tonje Skar Reiersen, Michael Fukushima','The Norwegian Film Institute'),(30,'Eugenio Polgovsky','Eugenio Polgovsky','Eugenio Polgovsky','Camille Tauss, Cristian Manzutto','Banda Mixe de Oaxaca','Eugenio Polgovsky','Tecolote Films');
/*!40000 ALTER TABLE `produccion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `se presenta en`
--

DROP TABLE IF EXISTS `se presenta en`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `se presenta en` (
  `Documentales_idDocumentales` int NOT NULL,
  `Festival_idFestival` int NOT NULL,
  KEY `fk_Documentales_has_Festival_Festival1_idx` (`Festival_idFestival`),
  KEY `fk_Documentales_has_Festival_Documentales1_idx` (`Documentales_idDocumentales`),
  CONSTRAINT `fk_Documentales_has_Festival_Documentales1` FOREIGN KEY (`Documentales_idDocumentales`) REFERENCES `documentales` (`idDocumentales`),
  CONSTRAINT `fk_Documentales_has_Festival_Festival1` FOREIGN KEY (`Festival_idFestival`) REFERENCES `festival` (`idFestival`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `se presenta en`
--

LOCK TABLES `se presenta en` WRITE;
/*!40000 ALTER TABLE `se presenta en` DISABLE KEYS */;
/*!40000 ALTER TABLE `se presenta en` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-06-20 14:55:01
